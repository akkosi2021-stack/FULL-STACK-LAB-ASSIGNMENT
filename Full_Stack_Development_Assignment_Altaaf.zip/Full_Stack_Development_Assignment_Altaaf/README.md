### Full Stack Development Assignment

**Submitted by:** Altaaf

**Program:** MCA, GLA University, Mathura

A collection of 13 Full Stack Development lab tasks covering HTML/CSS, Vanilla JavaScript, Public APIs, Node.js, Express.js, EJS, MongoDB, and React.

## Prerequisites

* **Web Browser** (Chrome, Edge, Firefox) for Tasks 01–07

* **Node.js & npm** for Tasks 08–13

* **MongoDB** (local or Atlas) for Task 11 (`mongodb://127.0.0.1:27017/fsd_products`)

## 1. Frontend Tasks (01 – 07)

Open `index.html` inside each folder directly in your browser (or use VS Code Live Server):

| # | Folder | Description | Files |
| ----- | ----- | ----- | ----- |
| 01 | `01-concentric-circles` | Three nested concentric circles styled with CSS Flexbox | `index.html`, `style.css` |
| 02 | `02-ten-horizontal-cards` | Horizontal scrollable row of 10 web development topic cards | `index.html`, `style.css` |
| 03 | `03-todo-list` | Interactive To-Do list with add, complete, move up/down, and delete actions | `index.html`, `style.css`, `script.js` |
| 04 | `04-chessboard-js` | 8x8 Chessboard with Unicode pieces generated dynamically via JS DOM | `index.html`, `script.js` |
| 05 | `05-snake-ladder-game` | Two-player Snake & Ladder board game with dice roll and turn logic | `index.html`, `style.css`, `script.js` |
| 06 | `06-random-jokes-api` | Fetches and displays random jokes using `fetch()` | `index.html`, `style.css`, `script.js` |
| 07 | `07-universities-by-country-api` | Searches universities by country or name using the Hipolabs Universities API | `index.html`, `style.css`, `script.js` |

## 2. Node.js & Express Tasks (08 – 12)

Navigate into the respective task folder, install dependencies, and start the server:

```bash
npm install
npm start
```

| # | Folder | Tech Stack | Port | Notes |
| ----- | ----- | ----- | ----- | ----- |
| 08 | `08-express-routes-template-engine` | Express, EJS | `3000` | Multi-page SSR app with GET & POST routes (`/`, `/about`, `/services`, `/contact`, `/feedback`) |
| 09 | `09-express-restful-crud-products` | Express, EJS, `method-override` | `3000` | RESTful CRUD app for products using in-memory data and EJS views |
| 10 | `10-express-api-csr-products` | Express, Vanilla JS (`fetch`) | `3000` | Client-Side Rendered (CSR) product manager backed by JSON REST APIs |
| 11 | `11-express-mongodb-crud-products` | Express, EJS, Mongoose, `dotenv`, `method-override` | `3000` | MongoDB-backed product CRUD; copy `.env.example` to `.env` and ensure MongoDB is running |
| 12 | `12-ecommerce-app` | Express, Vanilla JS, JSON storage | `5000` | Mini e-commerce app with Buyer (catalog, cart, orders) and Seller views backed by `data/store.json` |

### Task 11 Environment Setup

```bash
cd 11-express-mongodb-crud-products
cp .env.example .env
# Default .env values:
# PORT=3000
# MONGO_URI=mongodb://127.0.0.1:27017/fsd_products
npm install
npm start
```

## 3. React Task (13)

| # | Folder | Tech Stack | Run Command |
| ----- | ----- | ----- | ----- |
| 13 | `13-react-portfolio` | React 18, Vite 6 | `npm install && npm run dev` |

```bash
cd 13-react-portfolio
npm install
npm run dev
```

To create a production build:

```bash
npm run build
```