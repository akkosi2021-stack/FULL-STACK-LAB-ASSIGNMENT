export const aboutInfo = {
  name: "Altaaf",
  course: "MCA Student at GLA University, Mathura",
  bio: "I am pursuing my MCA at GLA University, Mathura. I focus on Java programming and building clean full-stack web applications using React, Node.js, Express, and MongoDB.",
  location: "Mathura, UP"
};

export const skillsList = [
  { group: "Frontend", items: ["HTML5", "CSS3", "JavaScript", "React", "Bootstrap"] },
  { group: "Backend", items: ["Node.js", "Express.js", "EJS", "REST APIs"] },
  { group: "Databases", items: ["MongoDB", "MySQL"] },
  { group: "Languages", items: ["Java", "JavaScript", "SQL"] }
];

export const projectList = [
  {
    name: "LearnSphere",
    tech: "MERN Stack",
    desc: "Online course and assignment tracker built for university students."
  },
  {
    name: "CartFlow",
    tech: "Node.js & Express",
    desc: "Multi-tab e-commerce app with buyer cart and seller inventory controls."
  },
  {
    name: "DailyPlanner",
    tech: "React & LocalStorage",
    desc: "Task organizer with priority ordering, completion status, and filters."
  },
  {
    name: "UniLookup",
    tech: "JavaScript & Public API",
    desc: "Country and university search directory using REST API integration."
  },
  {
    name: "SpendWise",
    tech: "Express & MongoDB",
    desc: "Expense management app for tracking daily budgets and categories."
  },
  {
    name: "JSQuizPro",
    tech: "HTML, CSS & JavaScript",
    desc: "Interactive web quiz platform with instant result evaluation."
  }
];
